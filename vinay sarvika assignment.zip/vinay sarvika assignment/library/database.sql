CREATE DATABASE  library;

USE library;

CREATE  users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    password VARCHAR(50),
    role ENUM('admin', 'sub-admin', 'public') NOT NULL
);

CREATE  books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(100) NOT NULL,
    genre VARCHAR(100),
    quantity INT NOT NULL
);

-- Insert dummy data into the users table
INSERT INTO users (username, password, role) VALUES
    ('admin_user', 'admin_password', 'admin'),
    ('subadmin_user', 'subadmin_password', 'sub-admin'),
    ('public_user', 'public_password', 'public');

-- Insert dummy data into the books table
INSERT INTO books (title, author, genre, quantity) VALUES
    ('Book Title 1', 'Author 1', 'Genre 1', 5),
    ('Book Title 2', 'Author 2', 'Genre 2', 3),
    ('Book Title 3', 'Author 3', 'Genre 3', 7);
