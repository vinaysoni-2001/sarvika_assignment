const express = require('express');
const bodyParser = require('body-parser');
const router = require('./Router/router');

const app = express();

// Middleware 
app.use(bodyParser.json());

// Router for api routing
app.use('/', router);
module.exports = app;
