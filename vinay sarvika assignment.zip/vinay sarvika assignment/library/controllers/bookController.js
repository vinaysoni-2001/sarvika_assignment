const db = require('../config/database')

exports.getAllBooks = async (req, res) => {
    try {
    console.log("--------inside getAllBooks----------");
    let query = "SELECT * FROM books";
    const [rows,fields] = await db.query(query);
    console.log(rows);
    console.log(`------------------`)
    console.log(fields)

    if(rows && rows.length>0)
    {
        res.status(200).json({status:true,message:"books found",data:rows});
    }
    else{
        res.status(200).json({status:false,message:"books not found",data:[]});
    }
} catch (error) {
    console.log(`--------catch block called-------`)
    console.log(error.message);
    res.status(404).json({status:false,message:error.message});
}
};

exports.addBook = async(req,res) =>{
    try {
        const{title,author,genre,quantity} = req.body;
        console.log("🚀 ~ exports.addBook=async ~ req.body:", req.body)
        let value = [title,author,genre,quantity]
        let query = "insert into books (title, author, genre, quantity) values(?,?,?,?)";
        const [rows,field] = await db.query(query,value)
        
        console.log("🚀 ~ exports.addBook=async ~ rows:", rows)
        console.log(rows.affectedRows);
        if(rows.affectedRows >0 && rows)
        {
            res.status(200).json({status:true,message:"book inserted successfully"});
        }
        else{
            res.status(200).json({status:false,message:"Book not inserted"});
        }
    } catch (error) {
        console.log("🚀 ~ exports.addBook=async ~ error:", error.message)
        res.status(404).json({status:false,message:error.message});   
    }
}
exports.updateBook = async(req,res) =>{
    try {
        const{bookID,title,author,genre,quantity} = req.body;
        console.log("🚀 ~ exports.updateBook=async ~ req.body:", req.body)
        
        let value = [title,author,genre,quantity,bookID]
        let query = "UPDATE books SET title = ?, author = ?, genre = ?, quantity = ? where id = ?";
        const [rows,field] = await db.query(query,value)
        console.log("🚀 ~ exports.updateBook=async ~ rows:", rows)
        console.log("🚀 ~ exports.updateBook=async ~ field:", field)
        
        console.log(rows.affectedRows);
        if(rows.affectedRows >0 && rows)
        {
            res.status(200).json({status:true,message:"books updated successfully"});
        }
        else{
            res.status(200).json({status:false,message:"Books not updated"});
        }
    } catch (error) {
        console.log("🚀 ~ exports.updateBook=async ~ error:", error.message)
        res.status(404).json({status:false,message:error.message});
        
    }
}
exports.deleteBook = async(req,res) =>{
    try {
        const{bookID} = req.body;
        console.log("🚀 ~ exports.deleteBook ~ req.body:", req.body)
        
        let query = "DELETE FROM books WHERE id = ?";
        let value = [bookID]
        const [rows,field] = await db.query(query,value)
        console.log("🚀 ~ exports.deleteBook=async ~ rows:", rows)
        console.log("🚀 ~ exports.deleteBook=async ~ field:", field)
        console.log(rows.affectedRows);
        if(rows.affectedRows >0 && rows)
        {
            res.status(200).json({status:true,message:"book deleted successfully"});
        }
        else{
            res.status(200).json({status:false,message:"Book not deleted"});
        }
    } catch (error) {
        console.log("🚀 ~ exports.deleteBook=async ~ error:", error.message)
        res.status(404).json({status:false,message:error.message});
        
    }
}
