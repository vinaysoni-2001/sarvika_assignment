const db = require('../config/database')

// Example implementation of authentication and authorization middleware
exports.authenticateAndAuthorize = (roles) =>{ 

    return async (req, res, next) => 
{

    try {
        console.log(`----------roles---------:${roles}`);

        console.log(`---------req data---------`)
        console.log(req.body)
        const {userID} = req.body;

        const [rows,fields] = await db.query(`SELECT role from users where id = ${userID}`)
        console.log(rows);
        if(!rows || rows.length == 0)
        {
            res.status(403).json( {status : false, message: 'invalid user' });
        }
        else{
            const userRole = rows[0].role;
        // console.log(roles.includes(req.body.role))
        // Authenticate user for functionality
        if (!roles.includes(userRole)) {
            console.log(`------unauthorized`)
            res.status(403).json( {status : false, message: 'Unauthorized User' });
        }
        else{
            next();
        }
    }

    } catch (error) {
        console.log(`----------error log in error------`)
        console.log(error.message);
        res.status(403).json({status:false,message:error.message})
    }
};
}

