const express = require('express');
const router = express.Router();
const { getAllBooks,addBook,updateBook,deleteBook } = require('../controllers/bookController');
const { authenticateAndAuthorize } = require('../middlewares/authMiddleware');

// Middleware for checking user roles
// router.use(authenticateUser);

// CRUD operations for books
router.get('/fetch/books', authenticateAndAuthorize(['admin', 'sub-admin', 'public']), getAllBooks);
router.post('/insert/books', authenticateAndAuthorize(['admin']), addBook);
router.post('/update/books', authenticateAndAuthorize(['admin', 'sub-admin']), updateBook);
router.post('/delete/books', authenticateAndAuthorize(['admin']), deleteBook);

module.exports = router;
